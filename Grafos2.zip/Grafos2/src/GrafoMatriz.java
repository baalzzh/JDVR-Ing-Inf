import java.util.*;

public class GrafoMatriz {
    private int[][] matrizAdyacencia;
    private int numeroDeVertices;
    private String[] nombresVertices;

    //Constructor
    public GrafoMatriz(int[][] matriz, String[] nombres) {
        this.numeroDeVertices = matriz.length;
        this.matrizAdyacencia = new int[numeroDeVertices][numeroDeVertices];
        this.nombresVertices = nombres.clone();

        for (int i = 0; i < numeroDeVertices; i++) {
            for (int j = 0; j < numeroDeVertices; j++) {
                this.matrizAdyacencia[i][j] = matriz[i][j];
            }
        }
    }

//obtener índice de vértice x su nombre
    public int obtenerIndice(String nombre) {
        for (int i = 0; i < nombresVertices.length; i++) {
            if (nombresVertices[i].equals(nombre)) {
                return i;
            }
        }
        return -1;
    }

//obtener nombre de vértice x índice
    public String obtenerNombre(int indice) {
        if (indice >= 0 && indice < nombresVertices.length) {
            return nombresVertices[indice];
        }
        return "?";
    }

//Recorrer BFS desde un vértice dado
    public List<String> bfs(String inicio) {
        int inicioIdx = obtenerIndice(inicio);
        if (inicioIdx == -1) return new ArrayList<>();

        List<String> ordenDeVisita = new ArrayList<>();
        boolean[] visitado = new boolean[numeroDeVertices];
        Queue<Integer> cola = new LinkedList<>();

        visitado[inicioIdx] = true;
        cola.add(inicioIdx);

        while (!cola.isEmpty()) {
            int nodoActual = cola.poll();
            ordenDeVisita.add(obtenerNombre(nodoActual));

//Explorar vecinos en orden ascendente
            for (int vecino = 0; vecino < numeroDeVertices; vecino++) {
                if (matrizAdyacencia[nodoActual][vecino] == 1 && !visitado[vecino]) {
                    visitado[vecino] = true;
                    cola.add(vecino);
                }
            }
        }
        return ordenDeVisita;
    }

//Recorrer DFS desde un vértice dado
    public List<String> dfs(String inicio) {
        int inicioIdx = obtenerIndice(inicio);
        if (inicioIdx == -1) return new ArrayList<>();

        List<String> ordenDeVisita = new ArrayList<>();
        boolean[] visitado = new boolean[numeroDeVertices];
        dfsUtil(inicioIdx, visitado, ordenDeVisita);
        return ordenDeVisita;
    }

//auxiliar DFS

    private void dfsUtil(int nodoActual, boolean[] visitado, List<String> ordenDeVisita) {
        visitado[nodoActual] = true;
        ordenDeVisita.add(obtenerNombre(nodoActual));

        for (int vecino = 0; vecino < numeroDeVertices; vecino++) {
            if (matrizAdyacencia[nodoActual][vecino] == 1 && !visitado[vecino]) {
                dfsUtil(vecino, visitado, ordenDeVisita);
            }
        }
    }

//MétodoDFS usando una pila (Stack) en lugar de recursividad.

    public List<String> dfsIterativo(String inicio) {
        int inicioIdx = obtenerIndice(inicio);
        if (inicioIdx == -1) return new ArrayList<>();

        List<String> ordenDeVisita = new ArrayList<>();
        boolean[] visitado = new boolean[numeroDeVertices];
        Stack<Integer> pila = new Stack<>();

        pila.push(inicioIdx);

        while (!pila.isEmpty()) {
            int nodoActual = pila.pop();

            if (!visitado[nodoActual]) {
                visitado[nodoActual] = true;
                ordenDeVisita.add(obtenerNombre(nodoActual));
                for (int vecino = numeroDeVertices - 1; vecino >= 0; vecino--) {
                    if (matrizAdyacencia[nodoActual][vecino] == 1 && !visitado[vecino]) {
                        pila.push(vecino);
                    }
                }
            }
        }
        return ordenDeVisita;
    }

//mostrar matriz adyacencia
    public void mostrarMatriz() {
        System.out.println("\n=== MATRIZ DE ADYACENCIA ===");
        System.out.print("    ");
        for (String nombre : nombresVertices) {
            System.out.print(nombre + "  ");
        }
        System.out.println();

        for (int i = 0; i < numeroDeVertices; i++) {
            System.out.print(nombresVertices[i] + "   ");
            for (int j = 0; j < numeroDeVertices; j++) {
                System.out.print(matrizAdyacencia[i][j] + "  ");
            }
            System.out.println();
        }
    }

//mostrar lista adyacencia
    public void mostrarListaAdyacencia() {
        System.out.println("\n=== LISTA DE ADYACENCIA (derivada de la matriz) ===");
        for (int i = 0; i < numeroDeVertices; i++) {
            System.out.print(nombresVertices[i] + " -> ");
            for (int j = 0; j < numeroDeVertices; j++) {
                if (matrizAdyacencia[i][j] == 1) {
                    System.out.print(nombresVertices[j] + " ");
                }
            }
            System.out.println();
        }
    }
}