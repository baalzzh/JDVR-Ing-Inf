//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        System.out.println("╔════════════════════════════════════════════════════════════════╗");
        System.out.println("║     GRAFO NO DIRIGIDO - MATRIZ DE ADYACENCIA (EJERCICIO 2)     ║");
        System.out.println("║     VÉRTICES: A, B, C, D, E, F, G                              ║");
        System.out.println("╚════════════════════════════════════════════════════════════════╝");

        // ==================== DEFINIR LA MATRIZ DE ADYACENCIA ====================
        // Según la imagen proporcionada (grafo con 7 vértices A-G)
        // 1 = hay conexión, 0 = no hay conexión
        int[][] matrizAdyacencia = {
                // A  B  C  D  E  F  G
                {0, 1, 1, 0, 0, 0, 0}, // A
                {1, 0, 1, 1, 0, 0, 0}, // B
                {1, 1, 0, 1, 1, 0, 0}, // C
                {0, 1, 1, 0, 1, 1, 0}, // D
                {0, 0, 1, 1, 0, 1, 1}, // E
                {0, 0, 0, 1, 1, 0, 1}, // F
                {0, 0, 0, 0, 1, 1, 0}  // G
        };

        String[] vertices = {"A", "B", "C", "D", "E", "F", "G"};

        // Crear el grafo
        GrafoMatriz grafo = new GrafoMatriz(matrizAdyacencia, vertices);

        // Mostrar representaciones
        grafo.mostrarMatriz();
        grafo.mostrarListaAdyacencia();

        // ==================== RECORRIDO BFS ====================
        System.out.println("\n╔════════════════════════════════════════════════════════════════╗");
        System.out.println("║                    RECORRIDO BFS (Amplitud)                     ║");
        System.out.println("╚════════════════════════════════════════════════════════════════╝");

        String inicio = "A";
        System.out.println("\n▶ Iniciando BFS desde el vértice: " + inicio);
        System.out.println("  (Explora nivel por nivel, usando una COLA - FIFO)");
        System.out.println("  (Orden de exploración: etiquetas ascendentes A→B→C→...)\n");

        java.util.List<String> resultadoBFS = grafo.bfs(inicio);
        System.out.print("Orden de visita BFS: ");
        for (int i = 0; i < resultadoBFS.size(); i++) {
            System.out.print(resultadoBFS.get(i));
            if (i < resultadoBFS.size() - 1) System.out.print(" → ");
        }
        System.out.println("\n");

        // Explicación paso a paso del BFS
        System.out.println("📖 Explicación paso a paso (BFS):");
        System.out.println("   ┌─────────────────────────────────────────────────────────────┐");
        System.out.println("   │ Nivel 0: A                                                  │");
        System.out.println("   │                                                            │");
        System.out.println("   │ Nivel 1: Vecinos de A en orden ascendente → B, C           │");
        System.out.println("   │                                                            │");
        System.out.println("   │ Nivel 2: Vecinos de B (no visitados) → D                   │");
        System.out.println("   │          Vecinos de C (no visitados) → (B ya visitado), E  │");
        System.out.println("   │                                                            │");
        System.out.println("   │ Nivel 3: Vecinos de D (no visitados) → F                   │");
        System.out.println("   │          Vecinos de E (no visitados) → G                   │");
        System.out.println("   │                                                            │");
        System.out.println("   │ Nivel 4: Vecinos de F (todos visitados)                    │");
        System.out.println("   │          Vecinos de G (todos visitados)                    │");
        System.out.println("   └─────────────────────────────────────────────────────────────┘");

        // ==================== RECORRIDO DFS (Recursivo) ====================
        System.out.println("\n╔════════════════════════════════════════════════════════════════╗");
        System.out.println("║           RECORRIDO DFS (Profundidad) - VERSIÓN RECURSIVA       ║");
        System.out.println("╚════════════════════════════════════════════════════════════════╝");

        System.out.println("\n▶ Iniciando DFS recursivo desde el vértice: " + inicio);
        System.out.println("  (Explora hasta el fondo antes de retroceder - BACKTRACKING)");
        System.out.println("  (Orden de exploración: etiquetas ascendentes A→B→C→...)\n");

        java.util.List<String> resultadoDFS = grafo.dfs(inicio);
        System.out.print("Orden de visita DFS (recursivo): ");
        for (int i = 0; i < resultadoDFS.size(); i++) {
            System.out.print(resultadoDFS.get(i));
            if (i < resultadoDFS.size() - 1) System.out.print(" → ");
        }
        System.out.println("\n");

        // Explicación paso a paso del DFS recursivo
        System.out.println("📖 Explicación paso a paso (DFS Recursivo):");
        System.out.println("   ┌─────────────────────────────────────────────────────────────┐");
        System.out.println("   │ 1. dfs(A) → visita A                                        │");
        System.out.println("   │    └── dfs(B) → visita B (primer vecino de A)              │");
        System.out.println("   │        └── dfs(D) → visita D (primer vecino no visitado de B)│");
        System.out.println("   │            └── dfs(F) → visita F (primer vecino no visitado de D)│");
        System.out.println("   │                └── (vecinos de F: D y E, D visitado, E no visitado)│");
        System.out.println("   │                    └── dfs(E) → visita E                    │");
        System.out.println("   │                        └── dfs(G) → visita G (primer vecino no visitado de E)│");
        System.out.println("   │                            └── (retorno, sin nuevos vecinos)│");
        System.out.println("   │                        └── (retorno)                        │");
        System.out.println("   │                    └── (retorno)                            │");
        System.out.println("   │                └── (retorno)                                │");
        System.out.println("   │            └── (retorno)                                    │");
        System.out.println("   │        └── (retorno)                                        │");
        System.out.println("   │    └── (retorno)                                            │");
        System.out.println("   │ 2. Verificar vecinos restantes de A: C (ya visitado)       │");
        System.out.println("   └─────────────────────────────────────────────────────────────┘");

        // ==================== RECORRIDO DFS (Iterativo con Stack) ====================
        System.out.println("\n╔════════════════════════════════════════════════════════════════╗");
        System.out.println("║           RECORRIDO DFS (Profundidad) - VERSIÓN ITERATIVA       ║");
        System.out.println("║                         (usando STACK)                          ║");
        System.out.println("╚════════════════════════════════════════════════════════════════╝");

        System.out.println("\n▶ Iniciando DFS iterativo desde el vértice: " + inicio);
        System.out.println("  (Usa una pila LIFO en lugar de recursividad)\n");

        java.util.List<String> resultadoDFSIterativo = grafo.dfsIterativo(inicio);
        System.out.print("Orden de visita DFS (iterativo): ");
        for (int i = 0; i < resultadoDFSIterativo.size(); i++) {
            System.out.print(resultadoDFSIterativo.get(i));
            if (i < resultadoDFSIterativo.size() - 1) System.out.print(" → ");
        }
        System.out.println("\n");

        // ==================== VERIFICAR CONEXIONES ====================
        System.out.println("╔════════════════════════════════════════════════════════════════╗");
        System.out.println("║                    VERIFICACIÓN DE CONEXIONES                   ║");
        System.out.println("╚════════════════════════════════════════════════════════════════╝");

        System.out.println("\n📊 Conexiones del grafo:");
        System.out.println("   • A está conectado con: B, C");
        System.out.println("   • B está conectado con: A, C, D");
        System.out.println("   • C está conectado con: A, B, D, E");
        System.out.println("   • D está conectado con: B, C, E, F");
        System.out.println("   • E está conectado con: C, D, F, G");
        System.out.println("   • F está conectado con: D, E, G");
        System.out.println("   • G está conectado con: E, F");

        // ==================== RESUMEN FINAL ====================
        System.out.println("\n╔════════════════════════════════════════════════════════════════╗");
        System.out.println("║                          RESUMEN FINAL                          ║");
        System.out.println("╚════════════════════════════════════════════════════════════════╝");

        System.out.println("\n📊 Resultados obtenidos (iniciando desde A):");
        System.out.println("   • BFS (Amplitud - Cola):          " + resultadoBFS);
        System.out.println("   • DFS (Profundidad - Recursivo):  " + resultadoDFS);
        System.out.println("   • DFS (Profundidad - Iterativo):  " + resultadoDFSIterativo);

        System.out.println("\n✅ Ejercicio completado correctamente.");
    }
}